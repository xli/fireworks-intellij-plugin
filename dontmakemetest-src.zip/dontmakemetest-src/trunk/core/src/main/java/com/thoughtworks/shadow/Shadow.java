package com.thoughtworks.shadow;

public interface Shadow {
    void accept(ShadowVisitor visitor);
}
