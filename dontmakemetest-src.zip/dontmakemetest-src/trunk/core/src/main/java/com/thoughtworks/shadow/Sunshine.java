package com.thoughtworks.shadow;

import junit.framework.Test;

public interface Sunshine {
    Test shine(String testClassName);
}
