package com.thoughtworks.shadow;

import junit.framework.TestResult;

public interface Cabinet {
    void action(TestResult result);
}
