package com.thoughtworks.shadow.tests;

import junit.framework.TestCase;

public class Success2 extends TestCase {
    public void testSuccess1() throws Exception {
    }

    public void testSuccess2() throws Exception {
    }
}
