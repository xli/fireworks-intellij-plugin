package com.thoughtworks.fireworks.core.table;

public interface TraceLogViewer {
    void display(Throwable t);
}
