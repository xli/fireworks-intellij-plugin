package com.thoughtworks.fireworks.adapters;

public class DocumentAdapterException extends RuntimeException {
    public DocumentAdapterException(String msg) {
        super(msg);
    }
}
