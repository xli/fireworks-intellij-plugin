package com.thoughtworks.shadow.junit;

public class TestRunnerError extends Error {
    public TestRunnerError(String msg) {
        super(msg);
    }
}
