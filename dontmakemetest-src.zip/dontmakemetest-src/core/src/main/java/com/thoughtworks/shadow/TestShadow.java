package com.thoughtworks.shadow;

import junit.framework.Test;

public interface TestShadow extends Test, Shadow {
}
