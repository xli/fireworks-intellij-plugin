package com.thoughtworks.shadow.tests;

import junit.framework.TestCase;

public class SixTestMethods extends TestCase {
    public void test1() {
    }

    public void test2() {
    }

    public void test3() {
    }

    public void test4() {
    }

    public void test5() {
    }

    public void test6() {
    }
}
