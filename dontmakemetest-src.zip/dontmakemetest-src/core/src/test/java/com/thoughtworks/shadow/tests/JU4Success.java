package com.thoughtworks.shadow.tests;

import org.junit.Test;

public class JU4Success {
    @Test
    public void aTest() {

    }
}
