package com.thoughtworks.shadow.tests;

import junit.framework.TestCase;

public class NoTestMethod extends TestCase {
}
