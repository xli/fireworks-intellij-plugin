package com.thoughtworks.fireworks.controllers.tree;

import com.thoughtworks.shadow.ShadowVisitor;

public interface JumpToSourceAdaptee extends ShadowVisitor {
}
