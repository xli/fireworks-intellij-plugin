package com.thoughtworks.fireworks.controllers;

import junit.framework.TestResult;

public interface RunAllTestsActionListener {
    void actionPerformed(TestResult result);
}
