package com.thoughtworks.fireworks.controllers;

import java.awt.*;

public interface TestResultSummaryBgColorListener {
    void setBackground(Color color);
}
