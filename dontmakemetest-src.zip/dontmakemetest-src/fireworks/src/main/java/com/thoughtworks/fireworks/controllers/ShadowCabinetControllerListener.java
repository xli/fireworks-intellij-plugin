package com.thoughtworks.fireworks.controllers;

public interface ShadowCabinetControllerListener {
    void actionWasFired();
}
