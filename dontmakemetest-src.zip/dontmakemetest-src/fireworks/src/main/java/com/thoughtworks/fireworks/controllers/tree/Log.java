package com.thoughtworks.fireworks.controllers.tree;

import com.thoughtworks.fireworks.core.ConsoleViewAdaptee;

public interface Log {
    void output(ConsoleViewAdaptee consoleView);
}
