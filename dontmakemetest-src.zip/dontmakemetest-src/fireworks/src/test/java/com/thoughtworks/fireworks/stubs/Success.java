package com.thoughtworks.fireworks.stubs;

import junit.framework.TestCase;

public class Success extends TestCase {
    public Success() {
        super("testSuccess");
    }

    public void testSuccess() throws Exception {
    }
}
