package com.thoughtworks.shadow.tests;

import org.junit.Ignore;
import org.junit.Test;

public class JU4Ignore {
    @Test
    @Ignore
    public void shouldBeIgnored() {
    }
}
